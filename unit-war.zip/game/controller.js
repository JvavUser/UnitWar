let Controller = {
  controlUnit: null,
  lastX: 0,
  lastY: 0,
  scroll: false,
  openBuildMenu: false,
  keyState: {}
};

var buildMenu;
var menuItems = 7;
const menuWidth = 50;

function initController()
{
  buildMenu = {
    x: GameContext.width - menuWidth,
    y: GameContext.height * 0.1,
    width: menuWidth,
    height: GameContext.height * 0.8,
    selectedItem: -1,
    page: 0,
  };//Math.floor(buildMenu.height / menuWidth);
  
  buildMenu.height = (menuItems + 2) * menuWidth;
  buildMenu.y = (GameContext.height - buildMenu.height) / 2;
  buildMenu.pages = Math.floor(buildingList.length / menuItems);
}

function handleTouchStart(x, y) {
  Controller.lastX = x;
  Controller.lastY = y;
  Controller.scroll = false;
}

function handleTouchMove(x, y) {
  let lx = Controller.lastX;
  let ly = Controller.lastY;
  let w = GameContext.width / 2;
  let h = GameContext.height / 2;
  if (dst(lx, ly, x, y) > 0.1) {
    Controller.scroll = true;
  }

  if (Controller.scroll) {
    let dx = lx - x,
      dy = ly - y;
    GameContext.cameraX += dx;
    GameContext.cameraY += dy;

    GameContext.cameraX = Math.max(w, Math.min(MAP_WIDTH * TILE_SIZE - w, GameContext.cameraX));
    GameContext.cameraY = Math.max(h, Math.min(MAP_HEIGHT * TILE_SIZE - h, GameContext.cameraY));
  }

  Controller.lastX = x;
  Controller.lastY = y;
}

function handleTouchEnd(x, y) {
  if (!Controller.scroll) {
    if (Controller.openBuildMenu && isInRect(x, y, buildMenu.x, buildMenu.y, buildMenu.width, buildMenu.height)) {
      chooseBuildMenu(x, y);
      return;
    }
    inputDown(x + GameContext.cameraX - GameContext.width / 2, y + GameContext.cameraY - GameContext.height / 2);
  }
}

function chooseBuildMenu(x, y) {
  let item = Math.floor((y - buildMenu.y) / menuWidth);
  let items = Math.min(menuItems, buildingList.length - buildMenu.page * menuItems);

  if(item == 0) {
    if (buildMenu.page > 0) {
      buildMenu.page -= 1;
      buildMenu.selectedItem = -1;
    }
  } else if (item == items + 1) {
    if (buildMenu.page < buildMenu.pages) {
      buildMenu.page += 1;
      buildMenu.selectedItem = -1;
    }
  } else {
    buildMenu.selectedItem = item == buildMenu.selectedItem ? -1 : item;
  }
}

function inputDown(x, y) {
  if (Controller.controlUnit != null && Controller.controlUnit.dead) {
    Controller.controlUnit = null;
  }

  if (Controller.controlUnit == null) {
    var unit = getUnitByPoint(x, y);
    
    if(unit != null)
    {
      Controller.controlUnit = unit;
    }
  } else {
    var unit = getUnitByPoint(x, y);

    if (unit == null) {
      if(Controller.openBuildMenu && buildMenu.selectedItem != -1) {
        onTapBuild(x, y);
        return;
      }
      Controller.controlUnit.movePoint = {
        x: x,
        y: y
      };
    } else if (unit != Controller.controlUnit) {
      Controller.controlUnit.movePoint = Controller.controlUnit.target = unit;
    } else {
      Controller.controlUnit = null;
    }
  }
}

function onTapBuild(x, y) {
  let tx = Math.floor(x / TILE_SIZE);
  let ty = Math.floor(y / TILE_SIZE);
  let unit = Controller.controlUnit;
  
  //取消建筑
  for(let i = 0; i < unit.buildList.length; i++) {
    let p = unit.buildList[i];
    if(p.buildX == tx && p.buildY == ty) {
      unit.buildList.splice(i, 1);
      return;
    }
  }
  
  let index = buildMenu.page * menuItems + buildMenu.selectedItem;
  
  if(buildMenu.selectedItem == -1 || index > buildingList.length) {
    return;
  }
  
  unit.build(tx, ty, buildingTypes[buildingList[index - 1]]);
}

function getUnitByPoint(x, y) {
  for (let i = 0; i < units.length; i++) {
    let unit = units[i];
    if (dst(x, y, unit.x, unit.y) <= unit.size * 1.3) {
      return unit;
    }
  }

  return null;
}

function drawUI(ctx) {
  Controller.openBuildMenu = Controller.controlUnit != null && Controller.controlUnit.type.builder;

  if (Controller.controlUnit != null && !Controller.controlUnit.dead) {
    var unit = Controller.controlUnit;

    let w = GameContext.width;
    let h = GameContext.height;

    //Game Hud
    /**ctx.fillStyle = "#000000";
    ctx.fillText("HP:" + unit.health + "/" + unit.type.health, 20, 20);
    ctx.fillText("Fire:" + unit.fireTimer, 20, 30);**/
    if (unit.type.builder)
    {
      if (unit.startBuild)
      {
        //ctx.fillText("Build Time:" + Math.floor(unit.buildTime / unit.curretPlan.buildType.buildTime / 30 * 100) + "%", w, 50);
      }
    }
    //Unit
    let cx = GameContext.cameraX - GameContext.width / 2;
    let cy = GameContext.cameraY - GameContext.height / 2;

    ctx.save();
    ctx.translate(-cx, -cy);

    ctx.strokeStyle = "#CC3333";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(unit.x, unit.y, unit.size, 0, 2 * Math.PI);
    ctx.stroke();

    ctx.strokeStyle = "#66CC00";
    ctx.beginPath();
    ctx.arc(unit.x, unit.y, unit.range, 0, 2 * Math.PI);
    ctx.stroke();

    if (unit.movePoint != null) {
      ctx.strokeStyle = "#FF3300";
      ctx.beginPath();
      ctx.moveTo(unit.x, unit.y);
      ctx.lineTo(unit.movePoint.x, unit.movePoint.y);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(unit.movePoint.x, unit.movePoint.y, 10, 0, 2 * Math.PI);
      ctx.stroke();
    }
    
    if(unit.type.builder) {
      ctx.lineWidth = 2.5;
      ctx.font = "6px sans-serif";
      ctx.fillStyle = "#000000";
      ctx.textAlign = "center";
      ctx.strokeStyle = "#ff1111";
      
      for(let i = 0; i < unit.buildList.length; i++) {
        let plan = unit.buildList[i];
        let x = plan.buildX * TILE_SIZE;
        let y = plan.buildY * TILE_SIZE;
        ctx.strokeRect(x, y, TILE_SIZE, TILE_SIZE);
        ctx.fillText(plan.buildType.name, x + TILE_SIZE / 2, y + TILE_SIZE / 2, TILE_SIZE);
      }
      
      if(unit.curretPlan != null) {
        let plan = unit.curretPlan;
        let x = plan.buildX * TILE_SIZE;
        let y = plan.buildY * TILE_SIZE;
        
        ctx.strokeRect(x, y, TILE_SIZE, TILE_SIZE);
        
        ctx.fillStyle = "#aaaaaa";
        ctx.globalAlpha = unit.buildTime / plan.buildType.buildTime / 30;
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        
        ctx.fillStyle = "#000000";
        ctx.globalAlpha = 1.0;
        
        ctx.fillText(plan.buildType.name, x + TILE_SIZE / 2, y + TILE_SIZE / 2, TILE_SIZE);
      }
    }
    ctx.restore();
  }

  if (Controller.openBuildMenu) {
    drawBuildMenu(ctx);
  }
};


function drawBuildMenu(ctx) {
  let w = GameContext.width;
  let h = GameContext.height;

  ctx.fillStyle = "#808080";
  ctx.fillRect(buildMenu.x, buildMenu.y, buildMenu.width, buildMenu.height);
  
  let items = Math.min(menuItems, buildingList.length - buildMenu.page * menuItems)

  let y = buildMenu.y;
  for (let i = 0; i <= items + 1; i++) {
    let xx = buildMenu.x + menuWidth / 2;
    let yy = y + menuWidth / 2;
    let selected = i == buildMenu.selectedItem;
    
    ctx.strokeStyle = selected ? "#cc0000" : "#000000";
    ctx.strokeRect(buildMenu.x, y, menuWidth, menuWidth);
    
    ctx.fillStyle = "#000000";
    if(i == 0) {
      ctx.beginPath();
      ctx.moveTo(xx, yy - 10);
      ctx.lineTo(xx - 10, yy + 10);
      ctx.lineTo(xx + 10, yy + 10);
      ctx.fill();
      
      y += menuWidth;
      continue;
    } else if(i == items + 1) {
      ctx.beginPath();
      ctx.moveTo(xx, yy + 10);
      ctx.lineTo(xx - 10, yy - 10);
      ctx.lineTo(xx + 10, yy - 10);
      ctx.fill();
      
      y += menuWidth;
      continue;
    }
    
    ctx.textAlign = "center";
    let id = buildMenu.page * menuItems + i - 1;
    ctx.fillText(buildingList[id], xx, yy, menuWidth);
    
    y += menuWidth;
  }
}