function Effect(x, y, time) {
  this.x = x;
  this.y = y;
  this.time = time;
  this.active = true;
}

Effect.prototype.update = function () {
  if(this.time-- <= 0) {
    this.active = false;
  }
}

Effect.prototype.draw = function(ctx) {}

function Explode(x, y, size) {
  Effect.call(this, x, y, 15.0);
  this.size = size;
}

Explode.prototype = Object.create(Effect.prototype);
Explode.prototype.constructor = Explode;

Explode.prototype.draw = function(ctx) {
  let t = this.time;
  
  ctx.globalAlpha = t / 15.0;
  ctx.fillStyle = "#cccc00";
  
  ctx.beginPath();
  ctx.arc(this.x, this.y, (1.0 - t / 30.0) * this.size, 0, 2 * Math.PI);
  ctx.fill();
  
  ctx.globalAlpha = 1.0;
}

function CrackLine(x0, y0, x1, y1) {
  Effect.call(this, x0, y0, 10.0);
  this.toX = x1;
  this.toY = y1;
}

CrackLine.prototype = Object.create(Effect.prototype);
CrackLine.prototype.constructor = CrackLine;

CrackLine.prototype.draw = function(ctx) {
  let t = this.time / 10;

  ctx.globalAlpha = t;
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = t * 5;

  ctx.beginPath();
  ctx.moveTo(this.x, this.y);
  ctx.lineTo(this.toX, this.toY);
  ctx.stroke();

  ctx.globalAlpha = 1.0;
}

function Wave(x, y, size) {
  Effect.call(this, x, y, 120.0);
  this.size = size;
}

Wave.prototype = Object.create(Effect.prototype);
Wave.prototype.constructor = Wave;

Wave.prototype.draw = function(ctx) {
  let t = 1.0 - this.time / 120;

  ctx.globalAlpha = 1.0 - t;
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 10 - t * 10;

  ctx.beginPath();
  ctx.arc(this.x, this.y, this.size * t * t, 0, 2 * Math.PI);
  ctx.stroke();

  ctx.globalAlpha = 1.0;
}

