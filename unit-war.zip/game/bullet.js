function Bullet(x, y, angle, speed, liftime, size) {
  this.x = x;
  this.y = y;
  this.angle = angle;
  this.size = size;
  this.collide = true;
  this.knock = 0;

  this.vx = Math.cos(angle) * speed;
  this.vy = Math.sin(angle) * speed;
  this.speed = speed;
  this.time = liftime;
  this.active = true;

  this.damage = 20;
  this.team = -1;
  
  this.penetration = 1;
  this.collides = [];
}

Bullet.prototype.update = function() {
  this.x += this.vx;
  this.y += this.vy;

  if (this.collide)
  {
    let i = units.length;
    while (i--) {
      let u = units[i];
      if (this.collides.indexOf(u) == -1 && u.team != this.team && dst(u.x, u.y, this.x, this.y) < this.size + u.size) {
        u.hit(this.damage);
        this.collides.push(u);
        
        if(this.knock > 0) {
          u.vx += this.vx / this.speed * this.knock;
          u.vy += this.vy / this.speed * this.knock;
        }
        
        this.penetration--;
        if(this.penetration == 0) {
          this.time = -1;
          break;
        }
      }
    }
  }

  if (--this.time <= 0) {
    this.active = false;
    this.destroy();
    let explode = new Explode(this.x, this.y, this.size * 3);
    addEffect(explode);
  }
}

Bullet.prototype.destroy = function() {

}

Bullet.prototype.draw = function(ctx) {
  let s = this.size;
  ctx.save();
  ctx.translate(this.x, this.y);
  ctx.rotate(this.angle);

  ctx.strokeStyle = "#aaaa00";
  ctx.lineWidth = s;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(s * 3, 0);
  ctx.stroke();

  ctx.restore();
}