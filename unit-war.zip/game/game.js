var bullets = [];
var effects = [];
var units = [];
var unitTypes = {};
var buildingTypes = {};
var buildingList = [];
const TEAM_BLUE = 0;
const TEAM_RED = 1;

function registerBuild(name, obj) {
  buildingTypes[name] = obj;
  buildingList.push(name);
  obj.name = name;
}

function loadUnit(name) {
  let script = document.createElement('script');
  script.src = "game/units/" + name + ".js";
  document.body.appendChild(script);
}

function loadBuilding(name) {
  let script = document.createElement('script');
  script.src = "game/buildings/" + name + ".js";
  document.body.appendChild(script);
}

function setBuild(x, y, team, params) {
  addUnit(new Building(x, y, team, params));
}

function addBullet(bullet) {
  bullets.push(bullet);
}

function addEffect(effect) {
  effects.push(effect);
}

function addUnit(unit) {
  units.push(unit);
}

var definitionUnit = [
  //basic
  "builder",
  //t1
  "tank",
  "robot",
  "spider",
  "laser-tank",
  "armored-tank",
  "plane",
  
  //t2
  "gun-robot",
  "shotgun-spider",
  "destroy-tank",
  "death-plane"
];

for(let i in definitionUnit) {
  loadUnit(definitionUnit[i]);
}

var definitionBuilding = [
  "core",
  "unit-factory",
  
  "gun",
  "wall",
  "crack-tower",
  "shotgun",
  "cannon",
  
  //t2
  "pierce-gun",
  "missile-tower",
  "laser-tower",
  "unit-upgrader"
];

for (let i in definitionBuilding) {
  loadBuilding(definitionBuilding[i]);
}