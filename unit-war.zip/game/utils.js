const DIRS = {
    0: [0, 1],
    1: [1, 0],
    2: [-1, 0],
    3: [0, -1],
};

function dst(x0, y0, x1, y1) {
  let tx = x0 - x1;
  let ty = y0 - y1;
  return Math.sqrt(tx * tx + ty * ty);
}

function dstAbs(x0, y0, x1, y1) {
  return Math.abs(x0 - x1) + Math.abs(y0 - y1);
}

function target(array, x, y, pass) {
  var i = array.length;
  var ds = -1;
  var it = -1;
  while(i--) {
    if(pass(array[i])) {
      var d = dst(array[i].x, array[i].y, x, y);
      if(it == -1 || d < ds) {
        it = i;
        ds = d;
      }
    }
  }
  
  if(it == -1)
    return null;
  return array[it];
}

function targetRange(array, x, y, range, pass) {
  var i = array.length;
  var ds = range;
  var it = -1;
  while (i--) {
    if (pass(array[i])) {
      var d = dst(array[i].x, array[i].y, x, y);
      if (d < ds) {
        it = i;
        ds = d;
      }
    }
  }

  if (it == -1)
    return null;
  return array[it];
}

function rand(min, max) {
  return Math.random() * (max - min) + min;
}

function damage(x, y, damage, team, radius) {
  let i = units.length;
  while(i--) {
    let u = units[i];
    if(u.team != team && dst(u.x, u.y, x, y) < radius) {
      u.hit(damage);
    }
  }
}

function choose(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function isInScreen(x, y, size) {
  return x + size >= 0 && y + size >= 0 && x < GameContext.width && y < GameContext.height;
}

function isInRect(x0, y0, x1, y1, w, h) {
  return x0 >= x1 && x0 <= x1 + w && y0 >= y1 && y0 <= y1 + h;
}