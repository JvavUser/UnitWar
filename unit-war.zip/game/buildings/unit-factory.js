function makeFactory(health, buildTime, color, unit)
{
  let factory = {
    health: health,
    buildTime: buildTime,
    color: color,
    unit: unit,
    buildTime: 10,
    params: {
      startWork: false,
      buildTimer: 0,
      hasTank: false,
      unloadTimer: 0
    },

    update: function(build) {
      if (!build.startWork && !build.hasTank) {
        build.startWork = true;
        build.buildTimer = 60 * this.buildTime;
      }

      if (build.startWork && build.buildTimer-- <= 0) {
        build.hasTank = true;
        build.startWork = false;
      }

      if (build.hasTank && build.unloadTimer++ % 20 == 0) {
        let targets = [];
        for (let i = 0; i < 4; i++) {
          let vx = DIRS[i][0] * TILE_SIZE;
          let vy = DIRS[i][1] * TILE_SIZE;
          if (!canPass(build.x + vx, build.y + vy)) {
            continue;
          }
          targets.push({ vx: vx, vy: vy });
        }

        if (targets.length > 0) {
          let target = choose(targets);
          let unit = new Unit(build.x + target.vx * 0.85, build.y + target.vy * 0.85, build.team, unitTypes[this.unit]);
          if (build.movePoint) {
            unit.commable = true;
            unit.movePoint = build.movePoint;
          }
          addUnit(unit);
          build.hasTank = false;
        }
      }
    },

    draw: function(build, ctx) {
      let s = build.size * 0.65;
      let t = 0.5 + 0.5 * Math.abs(Math.sin(build.buildTimer / 60 * Math.PI));

      ctx.save();
      ctx.translate(build.x, build.y);

      ctx.fillStyle = "#000000";
      ctx.beginPath();
      ctx.moveTo(0, -s);
      ctx.lineTo(s, s);
      ctx.lineTo(-s, s);
      ctx.closePath();
      ctx.fill();

      s = s * 0.9;
      ctx.fillStyle = this.color || "#FA8072";
      ctx.globalAlpha = t;
      ctx.beginPath();
      ctx.moveTo(0, -s);
      ctx.lineTo(s, s);
      ctx.lineTo(-s, s);
      ctx.closePath();
      ctx.fill();
      ctx.globalAlpha = 1.0;

      ctx.restore();
    }
  };
  return factory;
}

var tankFactory = makeFactory(500, 15, "#FA8072", "tank");
var spiderFactory = makeFactory(800, 5, "	#7B68EE", "spider");
var planeFactory = makeFactory(750, 10, "#00FA9A", "plane");
var robotFactory = makeFactory(1000, 25, "#FF33CC", "robot");

registerBuild('tankFactory', tankFactory);
registerBuild('spiderFactory', spiderFactory);
registerBuild('planeFactory', planeFactory);
registerBuild('robotFactory', robotFactory);