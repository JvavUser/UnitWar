var shotgun = {
  health: 500,
  fire: 10,
  range: 150,
  priority: -2,
  buildTime: 4,
  params: {
    target: null,
    fireTimer: 0,
    angle: 0,
    seekerTimer: 0
  },
  update: function(unit) {
    if ((unit.target == null || unit.target.dead) && (unit.seekerTimer++ >= 10)) {
      unit.seekerTimer = 0;
      unit.target = targetRange(units, unit.x, unit.y, this.range, (u) => u.team != unit.team);
      return;
    }

    if (unit.target == null) {
      return;
    }

    var ta = Math.atan2(unit.target.y - unit.y, unit.target.x - unit.x);
    unit.angle = ta * 0.8 + unit.angle * 0.2;
    var canShoot = Math.abs(ta - unit.angle) <= Math.PI / 30;

    if (canShoot && unit.fireTimer++ >= this.fire) {
      let an = Math.PI / 180 * 40;
      let step = an / 5;
      for (let i = unit.angle - an / 2; i < unit.angle + an / 2; i += step)
      {
        let bullet = new Bullet(unit.x, unit.y, i, 10, this.range / 10, 8);
        bullet.team = unit.team;
        bullet.damage = 20;
        bullet.knock = 1;
        addBullet(bullet);
      }
      unit.fireTimer = 0;
    }
  },
  draw: function(unit, ctx) {
    let s = unit.size;
    ctx.save();
    ctx.translate(unit.x, unit.y);
    ctx.rotate(unit.angle);

    ctx.fillStyle = "#333333";
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#333333";
    ctx.lineWidth = s * 0.6;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(s, 0);
    ctx.stroke();

    ctx.restore();
  }
};

registerBuild('shotgun', shotgun);