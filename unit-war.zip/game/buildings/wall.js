var wall = {
  health: 850,
  priority: -3,
  buildTime: 0.5,
  draw: function() {
  }
}

registerBuild('wall', wall);