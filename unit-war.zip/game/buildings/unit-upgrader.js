function makeUpgrader(upgradeTime, color, from, to) {
  let upgrader = {
    health: 500,
    upgradeTime: upgradeTime * 60,
    from: from,
    to: to,
    color: color,
    range: 150,
    buildTime: 15,
    params: {
      target: null,
      upgradeTimer: 0,
      startUpgrade: false,
      timer: 0
    }
  };
  
  upgrader.update = function(build) {
    build.timer++;
    if(build.startUpgrade) {
      if(build.target == null || build.target.dead) {
        build.startUpgrade = false;
        build.upgradeTimer = 0;
        return;
      }
      
      build.target.canMove = false;
      
      build.upgradeTimer++;
      if(build.upgradeTimer >= this.upgradeTime) {
        build.target.dead = true;
        build.upgradeTimer = 0;
        
        let unit = new Unit(build.target.x, build.target.y, build.team, unitTypes[this.to]);
        unit.commable = build.target.commable;
        addUnit(unit);
        
        build.startUpgrade = false;
      }
    } else {
      if(build.timer % 20 == 0) {
        let from = this.from;
        build.target = targetRange(units, build.x, build.y, this.range, 
        function(unit) { 
          return unit.team == build.team && unit.type == unitTypes[from] && unit.canMove;
        });
        
        if(build.target != null) {
          build.target.canMove = false;
          build.startUpgrade = true;
        }
      }
    }
  };
  upgrader.draw = function(build, ctx) {
    let s = build.size;
    let t = build.timer / 120;
    
    ctx.save();
    ctx.translate(build.x, build.y);
    ctx.rotate(t * Math.PI * 2);
    
    ctx.strokeStyle = ctx.fillStyle = this.color;
    ctx.lineWidth = s * 0.3;
    
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.5, 0, 2 * Math.PI);
    ctx.fill();
    
    for(let i = 0; i < 4; i++)
    {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(DIRS[i][0] * s * 0.8, DIRS[i][1] * s * 0.8);
      ctx.stroke();
    }
    ctx.restore();
    
    if(build.startUpgrade && build.target != null) {
      t = build.upgradeTimer / 120 * Math.PI * 2;
      let a = Math.abs(Math.cos(t * 0.25)) * 0.5 + 0.5;
      
      let target = build.target;
      ctx.lineWidth = 2;
      ctx.strokeStyle = this.color;
      
      for(let i = 0; i < 3; i++) {
        let an = i / 3 * Math.PI * 2 + t;
        let dx = Math.cos(an) * target.size * a;
        let dy = Math.sin(an) * target.size * a;
        
        ctx.beginPath();
        ctx.moveTo(target.x + dx, target.y + dy);
        ctx.lineTo(build.x, build.y);
        ctx.stroke();
      }
      
      ctx.beginPath();
      ctx.arc(target.x, target.y, target.size * a, 0, 2 * Math.PI);
      ctx.stroke();
    }
  }
  
  return upgrader;
}

let tankUpgrader = makeUpgrader(45, "#336633", "tank", "destroyTank");
let robotUpgrader = makeUpgrader(45, "#3366FF", "robot", "gunRobot");
let spiderUpgrader = makeUpgrader(45, "#FF6600", "spider", "shotgunSpider");
let planeUpgrader = makeUpgrader(45, "#333366", "plane", "deathPlane");
let laserTankUpgrader = makeUpgrader(8, "#8B008B", "tank", "laserTank");
let armoredTankUpgrader = makeUpgrader(5, "#FFD700", "tank", "armoredTank");

registerBuild('tankUpgrader', tankUpgrader);
registerBuild('robotUpgrader', robotUpgrader);
registerBuild('spiderUpgrader', spiderUpgrader);
registerBuild('planeUpgrader', planeUpgrader);
registerBuild('laserTankUpgrader', laserTankUpgrader);
registerBuild('armoredTankUpgrader', armoredTankUpgrader);