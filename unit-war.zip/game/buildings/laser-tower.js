var laserTower = {
  health: 1000,
  fire: 50,
  range: 200,
  priority: -2,
  buildTime: 5,
  params: {
    target: null,
    fireTimer: 0,
    angle: 0,
    seekerTimer: 0
  },
  update: function(unit) {
    if ((unit.target == null || unit.target.dead) && (unit.seekerTimer++ >= 10)) {
      unit.seekerTimer = 0;
      unit.target = targetRange(units, unit.x, unit.y, this.range, (u) => u.team != unit.team);
      return;
    }

    if (unit.target == null) {
      return;
    }

    var ta = Math.atan2(unit.target.y - unit.y, unit.target.x - unit.x);
    unit.angle = ta * 0.05 + unit.angle * 0.95;
    var canShoot = Math.abs(ta - unit.angle) <= Math.PI / 15;

    if (canShoot && unit.fireTimer++ >= this.fire) {
      let laser = new Laser(unit.x, unit.y, unit.angle, this.range * 1.25);
      laser.team = unit.team;
      laser.damage = 140;
      laser.penetration = -1;
      addBullet(laser);
      unit.fireTimer = 0;
    }
  },
  draw: function(unit, ctx) {
    let s = unit.size;
    ctx.save();
    ctx.translate(unit.x, unit.y);
    ctx.rotate(unit.angle);

    ctx.strokeStyle = ctx.fillStyle = "#333333";
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.4, 0, Math.PI * 2);
    ctx.fill();

    ctx.lineWidth = s * 0.4;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(s, 0);
    ctx.stroke();

    ctx.lineWidth = s * 0.3;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-s * 0.6, s * 0.4);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-s * 0.8, 0);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-s * 0.6, -s * 0.4);
    ctx.stroke();

    ctx.restore();
  }
};

registerBuild("laserTower", laserTower);