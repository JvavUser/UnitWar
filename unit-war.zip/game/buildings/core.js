var core = {
  health: 2000,
  priority: -1,
  buildTime: 999999999,
  params: {
    timer: 0
  },
  draw: function(unit, ctx) {
    unit.timer += 1 + (1.0 - unit.health / this.health) * 4;
    
    let s = unit.size;
    
    ctx.fillStyle = "#000000";
    ctx.beginPath();
    ctx.arc(unit.x, unit.y, s * 0.8, 0, 2 * Math.PI);
    ctx.fill();
    
    ctx.fillStyle = "#3366FF";
    ctx.globalAlpha = 0.5 + Math.abs(Math.sin(unit.timer / 20)) * 0.5;
    ctx.beginPath();
    ctx.arc(unit.x, unit.y, s * 0.8, 0, 2 * Math.PI);
    ctx.fill();
    ctx.globalAlpha = 1.0;
  },
  destroy: function(unit) {
    addEffect(new Wave(unit.x, unit.y, 800));
    //damage(this.x, this.y, 500, this.team, 800);
  }
};