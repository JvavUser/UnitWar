var missileTower = {
  health: 1200,
  fire: 40,
  range: 320,
  priority: -2,
  buildTime: 6,
  params: {
    target: null,
    fireTimer: 0,
    angle: 0,
    seekerTimer: 0
  },
  update: function(unit) {
    if ((unit.target == null || unit.target.dead) && (unit.seekerTimer++ >= 10)) {
      unit.seekerTimer = 0;
      unit.target = targetRange(units, unit.x, unit.y, this.range, (u) => u.team != unit.team);
      return;
    }

    if (unit.target == null) {
      return;
    }

    var ta = Math.atan2(unit.target.y - unit.y, unit.target.x - unit.x);
    unit.angle = ta * 0.45 + unit.angle * 0.55;
    var canShoot = Math.abs(ta - unit.angle) <= Math.PI / 30;

    if (canShoot && unit.fireTimer++ >= this.fire) {
      for(let i = -1; i <= 1; i++)
      {
        let an = Math.PI / 8 * i;
        let bullet = new Missile(unit.x, unit.y, unit.angle + an, 5, this.range / 5, 7.5);
        bullet.team = unit.team;
        bullet.damage = 20;
        bullet.splashDamage = 40;
        bullet.radius = 32;
        bullet.target = unit.target;
        addBullet(bullet);
      }
      unit.fireTimer = 0;
    }
  },
  draw: function(unit, ctx) {
    let s = unit.size;
    ctx.save();
    ctx.translate(unit.x, unit.y);
    ctx.rotate(unit.angle);

    ctx.strokeStyle = ctx.fillStyle = "#333333";
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.6, 0, Math.PI * 2);
    ctx.fill();

    ctx.lineWidth = s * 1.2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(s * 0.85, 0);
    ctx.stroke();

    ctx.restore();
  }
};

registerBuild('missileTower', missileTower);