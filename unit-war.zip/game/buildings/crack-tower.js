var crackTower = {
  health: 300,
  range: 150,
  buildTime: 3,
  params: {
    crackTimer: 0
  },

  update: function(build) {
    if (build.crackTimer++ >= 10) {
      build.crackTimer = 0;

      var bullet = targetRange(bullets, build.x, build.y, this.range, (unit) => unit.time > 0 && unit.team != build.team);
      if (bullet != null)
      {
        bullet.time = -1;
        addEffect(new CrackLine(build.x, build.y, bullet.x, bullet.y));
      }
    }
  },
  draw: function(build, ctx) {
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(build.x, build.y, build.size * 0.65, 0, 2 * Math.PI);
    ctx.fill();

    ctx.fillStyle = "#9966FF";
    ctx.beginPath();
    ctx.arc(build.x, build.y, build.size * 0.5, 0, 2 * Math.PI);
    ctx.fill();
  }
};

registerBuild("crackTower", crackTower);