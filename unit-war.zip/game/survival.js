const SurvivalMode = {
  wave: 0,
  waveTimer: 0
};

SurvivalMode.update = function() {
  
}