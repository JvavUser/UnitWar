function Laser(x, y, angle, length) {
  this.x = x;
  this.y = y;
  this.vx = Math.cos(angle);
  this.vy = Math.sin(angle);
  this.size = this.length = length;
  
  this.damage = 100;
  this.team = -1;
  this.time = 0;
  this.active = true;
  this.penetration = -1;
}

Laser.prototype.update = function() {
  if(this.time == 0) {
    let step = 15;
    let len = this.length / step;
    let hitteds = [];
    
    outter:
    for(let i = 0; i <= len; i++) {
      let x = this.x + this.vx * i * step;
      let y = this.y + this.vy * i * step;
      
      for(let j = 0; j < units.length; j++) {
        let unit = units[j];
        if(hitteds.indexOf(unit) != -1) {
          continue;
        }
        if(unit.team != this.team && dst(x, y, unit.x, unit.y) < step) {
          unit.hit(this.damage);
          hitteds.push(unit);
          
          this.penetration--;
          if(!this.penetration) {
            this.length = i * step;
            break outter;
          }
        }
      }
    }
  }
  this.time++;
  if(this.time >= 20) {
    this.active = false;
  }
}

Laser.prototype.draw = function(ctx) {
  let t = this.time / 20;
  ctx.strokeStyle = "#aa1111";
  ctx.fillStyle = "#aa1111";
  ctx.lineWidth = 5 - t * 5;
  
  ctx.beginPath();
  ctx.arc(this.x, this.y, 3 - 3 * t, 0, 2 * Math.PI);
  ctx.fill();
  
  ctx.beginPath();
  ctx.arc(this.x + this.vx * this.length, this.y + this.vy * this.length, 3 - t * 3, 0, 2 * Math.PI);
  ctx.fill();
  
  ctx.beginPath();
  ctx.moveTo(this.x, this.y);
  ctx.lineTo(this.x + this.vx * this.length, this.y + this.vy * this.length);
  ctx.stroke();
}