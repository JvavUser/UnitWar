function Unit(x, y, team, params) {
  this.angle = this.towerAngle = 0;
  this.x = x;
  this.y = y;
  this.health = params.health;
  this.size = params.size;
  this.type = params;
  this.speed = params.speed;
  this.range = params.range;
  this.fireTimer = 0;
  this.team = team;
  this.armor = params.armor ? params.armor : 0;
  this.retargetTimer = 0;

  this.rotateSpeed = params.rotateSpeed ? params.rotateSpeed : 0.1;

  this.target = null;
  this.dead = false;
  this.vx = this.vy = 0;
  this.preX = x;
  this.preY = y;
  this.avgX = 0;
  this.avgY = 0;
  this.shield = 0;
  this.hitTime = 0;
  
  this.canMove = true;
  this.canControl = true;

  this.commable = false;
  this.movePoint = null;

  if (params.params != null)
  {
    for (let key in params.params) {
      this[key] = params.params[key];
    }

    if (params.behaviour) {
      this.behaviour = params.behaviour;
    }
  }
  
  if(this.type.builder) {
    this.buildList = [];
  }
}

Unit.prototype.update = function() {
  if (this.health <= 0) {
    this.dead = true;
    this.destroy();
    return;
  }

  if (this.behaviour) {
    this.behaviour(this);
  }
  
  if(this.hitTime > 0) {
    this.hitTime--;
  }

  this.updateFire();
  this.updateMove();
  
  var dx = this.x + this.vx;
  var dy = this.y + this.vy;
  this.preX = this.x;
  this.preY = this.y;
  if (this.canMove && (this.type.fly || canPass(dx, dy, this.type.climb)))
  {
    this.x += this.vx;
    this.y += this.vy;
  } else {
    this.vx = this.vy = 0;
  }
  
  let ta = Math.atan2(this.vy, this.vx);
  this.angle = (this.angle * 20 + ta) / 21;
  
  if (this.target != null && this.target.dead) {
    this.target = null;
    return;
  }
  
  if(this.type.builder) {
    return;
  }
  
  if (this.target != null && !this.commable) {
    if (this.retargetTimer++ >= 20) {
      this.retargetTimer = 0;
      this.target = target(units, this.x, this.y, (unit) => unit.team != this.team);
      return;
    }

  } else if (!this.commable) {
    this.target = target(units, this.x, this.y, (unit) => unit.team != this.team);
  }
}

Unit.prototype.moveTo = function(x, y) {
  if (dst(x, y, this.x, this.y) < this.range * 0.9) {
    this.vx *= 0.9;
    this.vy *= 0.9;
  } else {
    if (this.type.fly) {
      this.moveDirect(x, y);
    } else {
      this.movePath(x, y);
    }
  }
}

Unit.prototype.updateMove = function() {
  if(!this.canControl) {
    return;
  }
  
  let toPos = null;
  if (this.commable) {
    toPos = this.movePoint;
  } else {
    toPos = this.target;
  }

  if(toPos != null) {
    this.moveTo(toPos.x, toPos.y);
  }
}

Unit.prototype.updateFire = function() {
  if (this.target == null || this.type.fire <= 0) {
    return;
  }
  ta = Math.atan2(this.target.y - this.y, this.target.x - this.x);
  this.towerAngle = ta * this.rotateSpeed + this.towerAngle * (1 - this.rotateSpeed);
  var canShoot = Math.abs(ta - this.towerAngle) < Math.PI / 30;

  if (dst(this.x, this.y, this.target.x, this.target.y) <= this.range) {
    if (canShoot) {
      if (++this.fireTimer >= this.type.fire) {
        this.type.shoot(this);
        this.fireTimer = 0;
      }
    }
  }
}

Unit.prototype.moveDirect = function(x, y) {
  var len = dst(this.x, this.y, x, y);

  if (len < this.speed) {
    len = this.speed;
  }

  var tx = (x - this.x) * this.speed / len;
  var ty = (y - this.y) * this.speed / len;
  this.vx = (this.vx * 30 + tx) / 31;
  this.vy = (this.vy * 30 + ty) / 31;
}

Unit.prototype.movePath = function(x, y) {
  var dir = -1;
  var best = -1,
    bestP = -1;
  for (var i = 0; i < 4; i++) {
    let vx = DIRS[i][0];
    let vy = DIRS[i][1];
    var dx = this.x + vx * this.speed;
    var dy = this.y + vy * this.speed;

    if (!canPass(dx, dy, this.type.climb)) {
      continue;
    }
    var pass = 0;
    dx = this.x + DIRS[i][0] * TILE_SIZE;
    dy = this.y + DIRS[i][1] * TILE_SIZE;
    for (let j = 0; j < 4; j++) {
      if (canPass(dx + TILE_SIZE * DIRS[j][0], dy + DIRS[j][1] * TILE_SIZE, this.type.climb)) {
        pass++;
      }
    }

    if (pass <= 1) {
      continue;
    }

    var cost = dst(dx, dy, x, y) / this.speed;
    let debug = dst(this.preX, this.preY, x, y) / this.speed;
    cost -= debug;
    if (dir == -1 || cost < best)
    {
      dir = i;
      best = cost;
      this.debug = debug;
    }
  }

  if (dir != -1) {
    this.bestDir = ["down", "left", "right", "up"][dir];
    var dx = DIRS[dir][0] * this.speed;
    var dy = DIRS[dir][1] * this.speed;
    this.vx = (this.vx * 30 + dx) / 31;
    this.vy = (this.vy * 30 + dy) / 31;
  }
}

Unit.prototype.draw = function(ctx) {
  ctx.fillStyle = "#000000";
  ctx.fillRect(this.x - 25, this.y - this.size - 3, 50, 3);
  ctx.fillStyle = "#11cc11";
  ctx.fillRect(this.x - 25, this.y - this.size - 3, 50 * this.health / this.type.health, 3);

  this.type.draw(this, ctx);
  /**ctx.lineWidth = 1;
  ctx.strokeStyle = "#ff00ff";
  ctx.fillStyle = "#000000";
  ctx.fillText("dst:" + Math.floor(this.debug), this.x, this.y);
  ctx.fillText("dir:" + this.bestDir, this.x, this.y - 10);
  ctx.fillText("preX:" + Math.floor(this.preX), this.x, this.y + 10);
  ctx.fillText("preY:" + Math.floor(this.preY), this.x, this.y + 20);
  ctx.fillText("X:" + Math.floor(this.x), this.x, this.y + 30);
  ctx.fillText("Y:" + Math.floor(this.y), this.x, this.y + 40);
  //ctx.fillText("preX:" + Math.floor(this.preX), this.x, this.y + 5);
**/
  /**ctx.beginPath();
  ctx.moveTo(this.x, this.y);
  ctx.lineTo(this.preX, this.preY);
  ctx.stroke();**/
  
  if(this.shield > 0 && this.hitTime >= 0) {
    ctx.fillStyle = "#dddddd";
    ctx.globalAlpha = this.hitTime / 15.0 * 0.75;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size * 1.25, 0, 2 * Math.PI);
    ctx.fill();
    ctx.globalAlpha = 1;
  }
}

Unit.prototype.hit = function(dmg) {
  this.hitTime = 15;
  if(this.shield > 0) {
    this.shield -= dmg;
    if(this.shield < 0) {
      dmg = -this.shield;
    } else {
      return;
    }
  }
  let d = Math.max(dmg - this.armor, dmg / 20);
  this.health -= d;
}

Unit.prototype.destroy = function() {
  let explode = new Explode(this.x, this.y, this.size * 2);
  addEffect(explode);
}