function Missile(x, y, angle, speed, lifetime, size) {
  this.x = x;
  this.y = y;
  this.vx = Math.cos(angle) * speed;
  this.vy = Math.sin(angle) * speed;
  this.time = lifetime;
  this.speed = speed;
  this.angle = angle;

  this.damage = 30;
  this.splashDamage = 12;
  this.size = size;
  this.radius = 30;
  this.active = true;
  this.team = -1;

  this.trailTimer = 0;
  this.lastPos = new Array(5);
  for (let i = 0; i < 5; i++) {
    this.lastPos[i] = new Object();
    this.lastPos[i].x = x;
    this.lastPos[i].y = y;
  }
}

Missile.prototype.update = function() {
  this.x += this.vx;
  this.y += this.vy;

  let an = Math.atan2(this.vy, this.vx);
  this.angle = an;

  let i = units.length;
  while (i--) {
    let u = units[i];
    if (u.team != this.team && dst(u.x, u.y, this.x, this.y) < this.size + u.size) {
      u.hit(this.damage);
      this.time = -1;
      break;
    }
  }

  if (this.target != null && !this.target.dead) {
    var len = dst(this.x, this.y, this.target.x, this.target.y);
    if (len < this.speed) {
      len = this.speed;
    }
    var tx = (this.target.x - this.x) * this.speed / len;
    var ty = (this.target.y - this.y) * this.speed / len;
    this.vx = (this.vx * 20 + tx) / 21;
    this.vy = (this.vy * 20 + ty) / 21;
  }

  if (this.time-- <= 0) {
    this.active = false;
    this.destroy();
    let explode = new Explode(this.x, this.y, this.radius);
    addEffect(explode);
  }
  
  if(this.trailTimer++ >= 2) {
    this.trailTimer = 0;
    for(let i = 0; i < 4; i++) {
      this.lastPos[i].x = this.lastPos[i + 1].x;
      this.lastPos[i].y = this.lastPos[i + 1].y;
    }
    this.lastPos[4].x = this.x;
    this.lastPos[4].y = this.y;
  }
}

Missile.prototype.draw = function(ctx) {
  let s = this.size;
  ctx.fillStyle = "#aaaa00";

  ctx.save();
  ctx.translate(this.x, this.y);
  ctx.rotate(this.angle);

  ctx.beginPath();
  ctx.moveTo(s, 0);
  ctx.lineTo(-s, s * 0.8);
  ctx.lineTo(-s, s * -0.8);
  ctx.closePath();
  ctx.fill();
  
  ctx.restore();
  
  for (let i = 0; i < 5; i++) {
    let s = i / 5 * this.size * 0.5;
    
    ctx.beginPath();
    ctx.arc(this.lastPos[i].x, this.lastPos[i].y, s, 0, 2 * Math.PI);
    ctx.fill();
  }
}

Missile.prototype.destroy = function() {
  damage(this.x, this.y, this.splashDamage, this.team, this.radius);
}