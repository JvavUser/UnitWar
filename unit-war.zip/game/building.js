function Building(x, y, team, params) {
  this.tx = x;
  this.ty = y;
  this.x = x * TILE_SIZE + TILE_SIZE * 0.5;
  this.y = y * TILE_SIZE + TILE_SIZE * 0.5;
  
  this.health = params.health;
  this.size = TILE_SIZE / 2;
  this.type = params;
  this.dead = false;
  this.team = team;
  
  for(key in params.params) {
    this[key] = params.params[key];
  }
  
  Map[this.tx][this.ty] = 2;
}

Building.prototype.update = function() {
  if(this.health <= 0) {
    this.dead = true;
    this.destroy();
    return;
  }
  
  if(this.type.update) {
    this.type.update(this);
  }
}

Building.prototype.hit = function(damage) {
  this.health -= damage;
}

Building.prototype.draw = function(ctx) {
  ctx.fillStyle = "#aaaaaa";
  ctx.fillRect(this.tx * TILE_SIZE, this.ty * TILE_SIZE, TILE_SIZE, TILE_SIZE);
  let a = this.health / this.type.health;
  
  ctx.fillStyle = "#555555";
  ctx.globalAlpha = 1.0 - a;
  ctx.fillRect(this.tx * TILE_SIZE, this.ty * TILE_SIZE, TILE_SIZE, TILE_SIZE);
  ctx.globalAlpha = 1.0;
  
  this.type.draw(this, ctx);
}

Building.prototype.destroy = function() {
  if(this.type.destroy) {
    this.type.destroy(this);
  } else {
    addEffect(new Wave(this.x, this.y, this.size));
  }
  Map[this.tx][this.ty] = 0;
}