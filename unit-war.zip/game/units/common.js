var tankRenderer = function(unit, ctx) {
  let s = this.size;
  //绘制坦克
  ctx.save();
  //变换
  ctx.translate(unit.x, unit.y);
  
  ctx.save();
  ctx.rotate(unit.angle);
  //主体
  ctx.fillStyle = "#aaaaaa";
  ctx.fillRect(s * -0.75, s * -0.5, s * 1.5, s);
  ctx.restore()
  
  ctx.rotate(unit.towerAngle - Math.PI / 2);
  //炮
  ctx.fillStyle = "#333333";
  ctx.beginPath();
  ctx.arc(0, 0, s * 0.25, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#333333";
  ctx.lineWidth = s * 0.1;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, s);
  ctx.stroke()
  
  ctx.restore();
}