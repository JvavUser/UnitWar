var plane = {
  health: 200,
  armor: 1,
  speed: 1.35,
  range: 170,
  fire: 35,
  size: 10,
  fly: true,
  rotateSpeed: 0.1,
  
  shoot: function(unit) {
    let bullet = new Missile(unit.x, unit.y, unit.towerAngle, 6, this.range / 6, 6);
    bullet.team = unit.team;
    bullet.damage = 10;
    bullet.splashDamage = 25;
    bullet.radius = 20;
    addBullet(bullet);
  },
  
  draw: function(unit, ctx) {
    let s = unit.size;
    ctx.fillStyle = "#cccccc";
    
    ctx.save();
    ctx.translate(unit.x, unit.y);
    ctx.rotate(unit.angle);
  
    ctx.beginPath();
    ctx.moveTo(s, 0);
    ctx.lineTo(s * -1.2, -s);
    ctx.lineTo(s * -0.6, 0);
    ctx.lineTo(s * -1.2, s);
    ctx.closePath();
    ctx.fill();
  
    ctx.restore();
  }
};

unitTypes["plane"] = plane;