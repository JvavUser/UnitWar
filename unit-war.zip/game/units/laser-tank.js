var laserTank = {
  health: 500,
  size: 30,
  range: 160,
  speed: 0.85,
  fire: 18,
  rotateSpeed: 0.05,
  armor: 1,
  params: {
     recoil: 0
  },
  
  draw: function(unit, ctx) {
    let s = this.size;
    let t = unit.fireTimer / this.fire;
    //绘制坦克
    ctx.save();
    //变换
    ctx.translate(unit.x, unit.y);
    
    ctx.save();
    ctx.rotate(unit.angle);
    //主体
    ctx.fillStyle = "#aaaaaa";
    ctx.fillRect(s * -0.75, s * -0.5, s * 1.5, s);
    ctx.restore()
    
    ctx.rotate(unit.towerAngle);
    //炮
    ctx.fillStyle = "#333333";
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.25, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#333333";
    ctx.lineWidth = s * 0.15;
    ctx.beginPath();
    ctx.moveTo((1 - t) * 0.1 * s, 0);
    ctx.lineTo((1 - t) * 0.1 * s + s, 0);
    ctx.stroke()
    
    ctx.restore();
  },
  shoot: function(unit, ctx) {
    unit.recoil = 1;
    let laser = new Laser(unit.x, unit.y, unit.towerAngle, this.range * 1.25);
    laser.team = unit.team;
    laser.damage = 30;
    laser.penetration = 3;
    addBullet(laser);
  }
};

unitTypes["laserTank"] = laserTank;