var robot = {
  health: 350,
  size: 15,
  speed: 1.1,
  range: 235,
  fire: 70,
  armor: 2,
  rotateSpeed: 0.05,
  
  params: {
    legStep: 0
  },
  
  draw: function(unit, ctx) {
    var s = this.size;
    var t = Math.abs(unit.vx) + Math.abs(unit.vy);
    let v = Math.sin(unit.legStep * 0.2);
    unit.legStep += t / 2;
    
    ctx.save();
    ctx.translate(unit.x, unit.y);
    
    //身体
    ctx.save();
    ctx.rotate(unit.angle);
    
    ctx.fillStyle = "#555555";
    ctx.fillRect(-s * 0.25 + v * s * 0.3, s * 0.75 - 10, s * 0.6, 10);
    ctx.fillRect(-s * 0.25 + -v * s * 0.3, -s * 0.75, s * 0.6, 10);

    ctx.fillStyle = "#cccccc";
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.75, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    
    //炮台
    ctx.rotate(unit.towerAngle - Math.PI / 2);
    ctx.fillStyle = "#333333";
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#333333";
    ctx.lineWidth = s * 0.3;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, s);
    ctx.stroke();
    
    ctx.restore();
  },
  
  shoot: function(unit) {
    let amount = 5;
    let t = Math.PI / 12 / amount;
    for(let i = 0; i < amount; i++) {
      let sp = rand(4, 6);
      let bullet = new Bullet(unit.x, unit.y, unit.towerAngle - Math.PI / 24 + t * i, sp, 40, unit.size * 0.25);
      bullet.damage = 12;
      bullet.team = unit.team;
      addBullet(bullet);
    }
  }
};

unitTypes["robot"] = robot;