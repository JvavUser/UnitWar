var spider = {
  health: 100,
  speed: 1.45,
  size: 8,
  fire: 8,
  range: 120,
  rotateSpeed: 1,
  climb: true,
  
  params: {
    legStep: 0
  },
  
  draw: function(unit, ctx) {
      let s = this.size;
      let t = Math.abs(unit.vx) + Math.abs(unit.vy);
      unit.legStep += t / this.speed / 2;
      let v = Math.sin(unit.legStep * 0.3);
      
      ctx.save();
      ctx.translate(unit.x, unit.y);
      
      ctx.save();
      ctx.rotate(unit.angle);
      
      ctx.lineWidth = s * 0.3;
      ctx.strokeStyle = "#cccccc";
      for(let i = -1; i <= 1; i++) {
        let a = i % 2 == 0 ? -1 : 1;
       // a *= 0.7 + (i + 2) / 3 * 0.3;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(i * s * 0.8 + v * s * 0.8 * a, s * 1.8);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(i * s * 0.8 - v * s * 0.8 * a, -s * 1.8);
        ctx.stroke();
      }
      
      ctx.fillStyle = "#aaaaaa";
      ctx.beginPath();
      ctx.arc(0, 0, s, 0, 2 * Math.PI);
      ctx.fill();
      ctx.restore();
      
      ctx.fillStyle = "#000000"
      ctx.beginPath();
      ctx.arc(0, 0, s * 0.5, 0, 2 * Math.PI);
      ctx.fill();
      
      ctx.globalAlpha = unit.health / this.health;
      ctx.fillStyle = "#ff1111"
      ctx.beginPath();
      ctx.arc(0, 0, s * 0.5, 0, 2 * Math.PI);
      ctx.fill();
      ctx.globalAlpha = 1.0;
      
      ctx.restore();
    },
  
    shoot: function(unit) {
      let bullet = new Bullet(unit.x, unit.y, unit.towerAngle + rand(-0.2, 0.2), 6, unit.range / 6, unit.size * 0.3);
      bullet.team = unit.team;
      bullet.damage = 8;
      addBullet(bullet);
    }
};

unitTypes["spider"] = spider;