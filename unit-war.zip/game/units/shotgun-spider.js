var shotgunSpider = {
  health: 2800,
  speed: 1.85,
  size: 25,
  fire: 20,
  range: 145,
  rotateSpeed: 0.5,
  climb: true,
  armor: 12,

  params: {
    legStep: 0,
    side: -1
  },

  draw: function(unit, ctx) {
    let s = this.size;
    let t = Math.abs(unit.vx) + Math.abs(unit.vy);
    unit.legStep += t / this.speed / 2;
    let v = Math.sin(unit.legStep * 0.25);

    ctx.save();
    ctx.translate(unit.x, unit.y);

    ctx.save();
    ctx.rotate(unit.angle);

    ctx.lineWidth = s * 0.3;
    ctx.strokeStyle = "#cccccc";
    for (let i = -1; i <= 1; i++) {
      let a = i % 2 == 0 ? -1 : 1;

      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(i * s * 0.8 + v * s * 0.8 * a, s * 1.8);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(i * s * 0.8 - v * s * 0.8 * a, -s * 1.8);
      ctx.stroke();
    }
    ctx.restore();

    ctx.rotate(unit.towerAngle);
    ctx.fillStyle = "#aaaaaa";
    ctx.beginPath();
    ctx.arc(0, 0, s, 0, 2 * Math.PI);
    ctx.fill();

    ctx.fillStyle = "#000000"
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.5, 0, 2 * Math.PI);
    ctx.fill();
    ctx.fillStyle = "#336633"
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.4, 0, 2 * Math.PI);
    ctx.fill();

    ctx.strokeStyle = "#cccccc";
    ctx.lineWidth = s * 0.3;

    s = s * 0.75;
    ctx.beginPath();
    ctx.moveTo(-s, -s);
    ctx.lineTo(s, -s);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-s, s);
    ctx.lineTo(s, s);
    ctx.stroke();

    ctx.restore();
  },

  shoot: function(unit) {
    let x, y, bullet;
    let s = unit.size * 0.75;
    unit.side *= -1;
    x = unit.x + Math.cos(unit.towerAngle + Math.PI / 2 * unit.side) * s;
    y = unit.y + Math.sin(unit.towerAngle + Math.PI / 2 * unit.side) * s;

    let amount = 3;
    for (let k = -amount; k <= amount; k++)
    {
      let an = unit.towerAngle + Math.PI / 180 * 20 *  k / amount;
      bullet = new Bullet(x, y, an, 8, this.range / 8 * 1.25, 8);
      bullet.team = unit.team;
      bullet.damage = 25;
      bullet.penetration = 4;
      addBullet(bullet);
    }
  }
};

unitTypes["shotgunSpider"] = shotgunSpider;