var builder = {
  health: 150,
  size: 10,
  speed: 2.5,
  range: 150,
  fire: -1,
  armor: 3,
  fly: true,
  builder: true,
  params: {
    curretPlan: null,
    buildTime: 0,
    startBuild: 0
  }
};

builder.params.build = function(x, y, buildType) {
  let plan = new Object();
  plan.buildX = x;
  plan.buildY = y;
  plan.buildType = buildType;
  plan.buildTime = 0;
  this.buildList.push(plan);
};

builder.behaviour = function(unit) {
  unit.canControl = unit.curretPlan == null;
  if(unit.startBuild) {
    if(unit.buildTime++ >= unit.curretPlan.buildType.buildTime * 30) {
      unit.startBuild = false;
      
      let plan = unit.curretPlan;
      setBuild(plan.buildX, plan.buildY, unit.team, plan.buildType);
      unit.curretPlan = null;
      return;
    }
  }
  
  if(unit.curretPlan == null) {
    if(unit.buildList.length > 0) {
      unit.curretPlan = this.buildList.pop();
      unit.buildTime = 0;
    }
  } else {
    let plan = unit.curretPlan;
    unit.startBuild = dst(plan.buildX * TILE_SIZE, plan.buildY * TILE_SIZE, unit.x, unit.y) < this.range;
    
    if(unit.startBuild) {
      unit.vx *= 0.75;
      unit.vy *= 0.75;
    } else {
      unit.moveTo(plan.buildX * TILE_SIZE, plan.buildY * TILE_SIZE);
    }
  }
}

builder.draw = function(unit, ctx) {
  let s = unit.size;
  ctx.fillStyle = "#555555";
  
  ctx.save();
  ctx.translate(unit.x, unit.y);
  ctx.rotate(unit.angle);
  
  ctx.beginPath();
  ctx.moveTo(s, 0);
  ctx.lineTo(s * -0.85, -s);
  ctx.lineTo(s * -0.6, 0);
  ctx.lineTo(s * -0.85, s);
  ctx.closePath();
  ctx.fill();
  
  ctx.restore();
  
  if(unit.startBuild) {
    let plan = unit.curretPlan;
    let t = unit.buildTime / 30 * Math.PI * 2;
    let a = Math.abs(Math.cos(t * 0.1)) * 0.25 + 0.75;
    
    let x = plan.buildX * TILE_SIZE + TILE_SIZE / 2;
    let y = plan.buildY * TILE_SIZE + TILE_SIZE / 2;
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#11ff11";
    
    for (let i = 0; i < 3; i++) {
      let an = i / 3 * Math.PI * 2 + t * 0.5;
      let dx = Math.cos(an) * TILE_SIZE / 2 * a;
      let dy = Math.sin(an) * TILE_SIZE / 2 * a;
    
      ctx.beginPath();
      ctx.moveTo(x + dx, y + dy);
      ctx.lineTo(unit.x, unit.y);
      ctx.stroke();
    }
    
    ctx.beginPath();
    ctx.arc(x, y, TILE_SIZE / 2 * a, 0, 2 * Math.PI);
    ctx.stroke();
  }
}

unitTypes["builder"] = builder;