var gunRobot = {
  health: 2000,
  size: 35,
  speed: 0.975,
  range: 180,
  fire: 7,
  armor: 10,
  rotateSpeed: 0.35,

  params: {
    legStep: 0,
    shootSide : 1,
  },

  draw: function(unit, ctx) {
    var s = this.size;
    var t = Math.abs(unit.vx) + Math.abs(unit.vy);
    let v = Math.sin(unit.legStep * 0.2);
    unit.legStep += t / 2;

    ctx.save();
    ctx.translate(unit.x, unit.y);

    //身体
    ctx.save();
    ctx.rotate(unit.angle);

    ctx.fillStyle = "#555555";
    ctx.fillRect(-s * 0.25 + v * s * 0.3, s * 0.75 - 10, s * 0.6, 10);
    ctx.fillRect(-s * 0.25 + -v * s * 0.3, -s * 0.75, s * 0.6, 10);

    ctx.fillStyle = "#cccccc";
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.75, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    //炮台
    ctx.rotate(unit.towerAngle);
    ctx.fillStyle = "#000000";
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#33FFFF";
    ctx.beginPath();
    ctx.arc(0, 0, s * 0.3, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.strokeStyle = "#333333";
    ctx.lineWidth = s * 0.3;
    
    s = s * 0.85;
    ctx.beginPath();
    ctx.moveTo(-s, -s);
    ctx.lineTo(s, -s);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-s, s);
    ctx.lineTo(s, s);
    ctx.stroke();

    ctx.restore();
  },

  shoot: function(unit) {
    let x, y, bullet;
    let s = unit.size;
    let side = unit.shootSide;
    unit.shootSide *= -1;
    
    x = unit.x + Math.cos(unit.towerAngle + Math.PI / 2 * side) * s;
    y = unit.y + Math.sin(unit.towerAngle + Math.PI / 2 * side) * s;
    bullet = new Bullet(x, y, unit.towerAngle - Math.PI / 24 * side, 8.5, this.range / 8.5, 8);
    bullet.team = unit.team;
    bullet.damage = 45.5;
    addBullet(bullet);
    
    /**x = unit.x + Math.cos(unit.towerAngle - Math.PI / 2) * s;
    y = unit.y + Math.sin(unit.towerAngle - Math.PI / 2) * s;
    bullet = new Bullet(x, y, unit.towerAngle + Math.PI / 24, 8.5, this.range / 8.5, 8);
    bullet.team = unit.team;
    bullet.damage = 40;
    addBullet(bullet);**/
  }
};

unitTypes["gunRobot"] = gunRobot;