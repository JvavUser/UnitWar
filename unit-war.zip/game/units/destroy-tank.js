//毁灭坦克
var destroyTank = {
  health: 2500,
  size: 45,
  range: 180,
  fire: 18,
  speed: 0.75,
  armor: 12,
  rotateSpeed: 0.05,

  draw: function(unit, ctx) {
    let s = this.size;
    //绘制坦克
    ctx.save();
    //变换
    ctx.translate(unit.x, unit.y);

    ctx.save();
    ctx.rotate(unit.angle);
    //主体
    ctx.fillStyle = "#aaaaaa";
    ctx.fillRect(s * -0.75, s * -0.5, s * 1.5, s);
    ctx.restore()

    ctx.rotate(unit.towerAngle);
    
    //炮
    ctx.strokeStyle = "#333333";
    ctx.lineWidth = s * 0.2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(s * 1.15, 0);
    ctx.stroke();
    
     ctx.strokeStyle = ctx.fillStyle = "#333333";
     ctx.beginPath();
     ctx.arc(0, 0, s * 0.3, 0, Math.PI * 2);
     ctx.fill();
     
     ctx.lineWidth = s * 0.3;
     ctx.beginPath();
     ctx.moveTo(0, 0);
     ctx.lineTo(-s * 0.4, s * 0.3);
     ctx.stroke();
     
     ctx.beginPath();
     ctx.moveTo(0, 0);
     ctx.lineTo(-s * 0.4, -s * 0.3);
     ctx.stroke();

    ctx.restore();
  },

  shoot: function(unit) {
    for(let i = -1; i <= 1; i++) {
      let an = Math.PI / 12 * i / 2;
      let laser = new Laser(unit.x, unit.y, unit.towerAngle + an, this.range * 1.15);
      laser.team = unit.team;
      laser.damage = 60;
      laser.penetration = 3;
      addBullet(laser);
    }
  }
}

unitTypes["destroyTank"] = destroyTank;