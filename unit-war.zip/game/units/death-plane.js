var deathPlane = {
  health: 2500,
  armor: 8,
  speed: 1.9,
  size: 25,
  range: 250,
  fire: 40,
  fly: true,
  rotateSpeed: 0.2,
  
  params: {
    
  },
  
  shoot: function(unit) {
    for(let i = -2; i <= 2; i++) {
      let an = unit.towerAngle + i * Math.PI / 15;
      let spd = rand(5, 7);
      let bullet = new Missile(unit.x, unit.y, an, spd, this.range / spd * 1.25, 8);
      bullet.team = unit.team;
      bullet.damage = 25;
      bullet.splashDamage = 35;
      bullet.radius = 35;
      bullet.target = unit.target;
      addBullet(bullet);
    }
  },
  
  draw: function(unit, ctx) {
    let s = unit.size;
    ctx.fillStyle = "#cccccc";
    
    ctx.save();
    ctx.translate(unit.x, unit.y);
    ctx.rotate(unit.angle);
    
    ctx.beginPath();
    ctx.moveTo(s, 0);
    
    ctx.lineTo(s * -1.2, -s);
    ctx.lineTo(s * -0.6, -s * 0.2);
    ctx.lineTo(s * -1.2, 0);
    ctx.lineTo(s * -0.6, s * 0.2);
    ctx.lineTo(s * -1.2, s);
    
    ctx.closePath();
    ctx.fill();
    
    ctx.restore();
  }
};

unitTypes["deathPlane"] = deathPlane;