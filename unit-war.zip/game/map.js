const TILE_SIZE = 32;

const COLORS = {
  0: "#11cc11",
  1: "#333300",
  2: "#000000",
  3: "#66CCFF"
};
const TILE_GROUND = 0;
const TILE_WATER = 3;
const TILE_ROCK = 1;

var MAP_WIDTH = 50, MAP_HEIGHT = 50;
var Map = null;

function canPass(x, y, climb) {
  var tx = Math.floor(x / TILE_SIZE);
  var ty = Math.floor(y / TILE_SIZE);
  if(tx < 0 || tx >= MAP_WIDTH || ty < 0 || ty >= MAP_HEIGHT) {
    return false;
  }
  
  let tile = Map[tx][ty];
  if(climb) {
    return tile != TILE_WATER;
  } else {
    return tile == TILE_GROUND;
  }
}

var COLOR_MAP = {
  "#ff00": 1,
  "#0ff0": 0,
  "#00ff": 3,
  "#0ffff": -1,
  "#ff0ff": -2,
  "#ffff0": -3
};

var mapLoader = document.getElementById('map-loader');
mapLoader = mapLoader.getContext('2d');

function loadMap(mapName) {
  let img = document.createElement("img");
  img.src = "map/" + mapName + ".png";
  img.onload = function() {
    initMap(img);
  };
}

function initMap(img) {
  mapLoader.drawImage(img, 0, 0);
  let data = mapLoader.getImageData(0, 0, img.width, img.height);
  
  MAP_WIDTH = data.width;
  MAP_HEIGHT = data.height;
  data = data.data;
  
  Map = new Array(MAP_WIDTH);
  for(let i = 0; i < MAP_HEIGHT; i++) {
    Map[i] = new Array(MAP_HEIGHT);
  }
  for(let i = 0; i < data.length; i += 4) {
    let y = Math.floor(i / 4 / MAP_WIDTH);
    let x = Math.floor((i / 4) % MAP_WIDTH);
    let id = "#" + data[i].toString(16) + data[i+1].toString(16) + data[i+2].toString(16);
    
    let terraria = COLOR_MAP[id];
    if(terraria == -1) {
      Map[x][y] = 0;
    } else if(terraria == -2) {
      //setBuild(x, y, TEAM_PLAYER, core);
    } else {
      Map[x][y] = terraria;
    }
  }
  
  if(window.ongamestart) {
    window.ongamestart();
  }
}