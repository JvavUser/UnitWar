var GameContext = {};
var canvas = document.getElementById('game');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var ctx = canvas.getContext('2d');

GameContext.width = canvas.width;
GameContext.height = canvas.height;
GameContext.cameraX = canvas.width / 2;
GameContext.cameraY = canvas.height / 2;
GameContext.tileWidth = Math.floor(canvas.width / TILE_SIZE) + 1;
GameContext.tileHeight = Math.floor(canvas.height / TILE_SIZE) + 1;

canvas.addEventListener('touchstart', function(event) {
  let touch = event.targetTouches[0];
  handleTouchStart(touch.clientX, touch.clientY);
});
canvas.addEventListener('touchmove', function(event) {
  let touch = event.targetTouches[0];
  handleTouchMove(touch.clientX, touch.clientY);
  event.preventDefault();
});
canvas.addEventListener('touchend', function(event) {
  let touch = event.changedTouches[0];
  //console.log(touch.x, touch.y);
  handleTouchEnd(touch.clientX, touch.clientY);
});
//loadMap('beach');

//window.ontouchstart = function(event) 

function placeBase(x, y, team, attack) {
  let factories = [
    tankFactory, spiderFactory, planeFactory, robotFactory,
    armoredTankUpgrader, spiderUpgrader, robotUpgrader, planeUpgrader,
    laserTankUpgrader
  ];
  let turrets = [
    shotgun, gun, laserTower, crackTower,
    pierceGun, missileTower
  ];

  setBuild(x, y, team, core);
  /**setBuild(x - 1, y - 1, team, laserTower);
  setBuild(x, y - 1, team, laserTower);
  setBuild(x + 1, y - 1, team, laserTower);
  setBuild(x + 1, y, team, missileTower);
  setBuild(x - 1, y, team, missileTower)
  setBuild(x + 1, y + 1, team, pierceGun);
  setBuild(x - 1, y + 1, team, pierceGun);
  
  if (attack)
  {
    setBuild(x, y + 1, team, choose(factories));
  } else {
    setBuild(x, y + 1, team, pierceGun);
  }**/

  let size = Math.floor(rand(3, 8));
  for (let i = x - size; i <= x + size; i++) {
    for (let j = y - size; j <= y + size; j++) {
      if (Map[i][j] == 0) {
        if(i == x - size || i == x + size || j == y - size || j == y + size) {
          if(Math.random() < 0.25) {
            setBuild(i, j, team, choose(factories));
          } else {
            setBuild(i, j, team, wall);
          }
        } else {
          setBuild(i, j, team, choose(turrets));
        }
      }
    }
  }
}
window.onload = function()
{
  //window.ongamestart();
  //console.log();
  initController();
  loadMap('sandbox');
}
window.ongamestart = function() {

  //addUnit(a = new Unit(32, 32, 0, builder));
  //a.commable = true;
  
  let cx = 500, cy = 500;
  GameContext.cameraX = cx;
  GameContext.cameraY = cy;
  
  let r = 500;
  let an = 360;
  let type = shotgunSpider;
  let a = deathPlane;
  
  addUnit(new Unit(cx, cy, 0, a));
  for(let i = 0; i < Math.PI * 2; i += Math.PI / 180 * an) {
    let x = cx + Math.cos(i) * r;
    let y = cy + Math.sin(i) * r;
    addUnit(new Unit(x, y, 2, type));
  }
  
  setInterval(updateAndDraw, 1000 / 60);
}

document.body.addEventListener('keydown', function(event) {
  Controller.keyState[event.keyCode] = true;
});
document.body.addEventListener('keyup', function(event) {
  Controller.keyState[event.keyCode] = false;
});

function updateKey() {
  if(Controller.keyState[37]) {
    GameContext.cameraX = Math.max(GameContext.cameraX - 5, GameContext.width / 2);
  } else if (Controller.keyState[39]) {
    GameContext.cameraX = Math.min(GameContext.cameraX + 5, MAP_WIDTH * TILE_SIZE - GameContext.width / 2);
  } else if (Controller.keyState[38]) {
    GameContext.cameraY = Math.max(GameContext.cameraY - 5, GameContext.height / 2);
  } else if (Controller.keyState[40]) {
    GameContext.cameraY = Math.min(GameContext.cameraY + 5, MAP_HEIGHT * TILE_SIZE - GameContext.height / 2);
  }
}

function updateAndDraw() {
  updateKey();
  
  let cx = GameContext.cameraX - GameContext.width / 2;
  let cy = GameContext.cameraY - GameContext.height / 2;

  ctx.save();
  ctx.translate(-cx, -cy);
  
  ctx.fillStyle = "#000000";
  ctx.fillRect(0, 0, GameContext.width, GameContext.height);

  let x = Math.max(0, Math.floor(cx / TILE_SIZE) - 1);
  let y = Math.max(0, Math.floor(cy / TILE_SIZE) - 1);
  let ex = Math.min(MAP_WIDTH, x + GameContext.tileWidth + 2);
  let ey = Math.min(MAP_HEIGHT, y + GameContext.tileHeight + 2);

  for (let i = x; i < ex; i++) {
    for (let j = y; j < ey; j++) {
      var tile = Map[i][j];
      ctx.fillStyle = COLORS[tile];
      ctx.fillRect(i * TILE_SIZE, j * TILE_SIZE, TILE_SIZE, TILE_SIZE);
    }
  }

  let i = units.length;
  while (i--) {
    var unit = units[i];
    unit.update();

    if (unit.dead) {
      units.splice(i, 1);
      continue;
    }
    if (isInScreen(unit.x - cx, unit.y - cy, unit.size * 2.5))
    {
      unit.draw(ctx);
    }
  }
  
  i = bullets.length;
  while (i--) {
    var bullet = bullets[i];
    bullet.update();

    if (!bullet.active) {
      bullets.splice(i, 1);
      continue;
    }

    if (isInScreen(bullet.x - cx, bullet.y - cy, bullet.size * 3))
    {
      //ctx.globalCompositeOperation = "destination-over";
      bullet.draw(ctx);
      /**ctx.fillStyle = "#aaaaaa";
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.arc(bullet.x, bullet.y, bullet.size, 0, 2 * Math.PI)
      ctx.fill();
      ctx.globalAlpha = 1.0;**/
    }
  }

  i = effects.length;
  while (i--) {
    var effect = effects[i];
    effect.update();

    if (!effect.active) {
      effects.splice(i, 1);
      continue;
    }

    effect.draw(ctx);
  }
  ctx.restore();

  drawUI(ctx);
}